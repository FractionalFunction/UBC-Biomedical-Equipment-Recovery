<?php

/*
 * Settings for the UBC Biomedical Equipment Recovery Website
 * 
 * This file may contain sensitive information!
 */

// Debug status
// Don't forget to turn this off in production!
define("DEBUG", false);

// Contact information
$contactInformation = array(
	"email" => "ubcequipmentrecovery@gmail.com",
);
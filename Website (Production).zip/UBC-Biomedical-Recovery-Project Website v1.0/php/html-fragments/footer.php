<div id="footer">
    <div class="container">
        <h3>The UBC Biomedical Equipment Recovery Project</h3>
        <span>Website developed by Richie Zhang. (<a href="https://github.com/FractionalFunction/UBC-Biomedical-Equipment-Recovery" target="_blank">Source Code</a>)</span>
    </div>
</div>

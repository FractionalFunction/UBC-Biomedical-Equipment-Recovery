#The UBC Biomedical Equipment Recovery Project

The UBC Biomedical Equipment Recovery Project is a student-led project by the Sir Winston
Churchill Secondary School IB class of 2017 to reclaim equipment discarded by the
UBC Biomedical Faculty.

Production release of the website for this project, version 1.0.

The website can be found at http://ubcequipmentrecovery.co/

Github Repository: https://github.com/FractionalFunction/UBC-Biomedical-Equipment-Recovery
